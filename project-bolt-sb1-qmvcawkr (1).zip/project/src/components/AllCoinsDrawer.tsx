import React, { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { getExchangeInfo } from "../utils/binanceApi";

type SymbolRow = { symbol: string; base: string; quote: string };

export default function AllCoinsDrawer({
  open,
  onClose,
  onSelect,
}: {
  open: boolean;
  onClose: () => void;
  onSelect: (symbol: string) => void;
}) {
  const [list, setList] = useState<SymbolRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [quote, setQuote] = useState<"USDT" | "FDUSD" | "USDC" | "BUSD" | "TUSD" | "ALL">("USDT");
  const [page, setPage] = useState(1);
  const pageSize = 50;

  // fetch once on open or when quote changes
  useEffect(() => {
    if (!open) return;
    (async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch exchange info directly
        const data = await getExchangeInfo();
        const rows: SymbolRow[] = (data?.symbols || [])
          .filter(
            (s: any) =>
              s?.status === "TRADING" &&
              s?.isSpotTradingAllowed &&
              (s?.permissions?.includes?.("SPOT") || true)
          )
          .map((s: any) => ({ 
            symbol: s.symbol, 
            base: s.baseAsset, 
            quote: s.quoteAsset 
          }));
        
        setList(rows);
        setPage(1);
      } catch (e: any) {
        setError("Failed to load symbols");
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    setPage(1);
  }, [quote, open]);

  const filtered = useMemo(() => {
    const rows = quote === "ALL" ? list : list.filter((r) => r.quote === quote);
    return rows.sort((a, b) => a.base.localeCompare(b.base));
  }, [list, quote]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pageSlice = filtered.slice((page - 1) * pageSize, page * pageSize);

  if (!open) return null;

  // Render as portal + fixed overlay so it doesn't push layout
  return createPortal(
    <div
      aria-modal
      role="dialog"
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.5)",
        zIndex: 1000,
        display: "flex",
        alignItems: "stretch",
        justifyContent: "flex-end",
      }}
      onKeyDown={(e) => {
        if (e.key === "Escape") onClose();
      }}
    >
      {/* sheet */}
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "min(520px, 95vw)",
          height: "100%",
          background: "#111",
          color: "#eee",
          padding: 16,
          boxShadow: "0 0 20px rgba(0,0,0,0.4)",
          overflow: "hidden",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <h3 style={{ margin: 0, fontWeight: 600, fontSize: 18 }}>All Coins (Spot)</h3>
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            <select
              value={quote}
              onChange={(e) => setQuote(e.target.value as any)}
              style={{ background: "#222", color: "#eee", borderRadius: 8, padding: "6px 8px" }}
              aria-label="Quote filter"
            >
              <option value="USDT">USDT</option>
              <option value="FDUSD">FDUSD</option>
              <option value="USDC">USDC</option>
              <option value="BUSD">BUSD</option>
              <option value="TUSD">TUSD</option>
              <option value="ALL">ALL</option>
            </select>
            <button
              onClick={() => {
                // Force reload of symbols
                setList([]);
                setLoading(true);
                // Re-trigger the effect
                const currentOpen = open;
                if (currentOpen) {
                  // The effect will re-run and reload data
                }
              }}
              title="Refresh"
              style={{ background: "#222", color: "#eee", borderRadius: 8, padding: "6px 10px" }}
            >
              ↻
            </button>
            <button
              onClick={onClose}
              style={{ background: "#2a2a2a", color: "#fff", borderRadius: 8, padding: "6px 10px" }}
              aria-label="Close"
            >
              ✕
            </button>
          </div>
        </div>

        <div
          style={{
            height: "calc(100% - 88px)",
            overflow: "auto",
            borderRadius: 12,
            background: "#0e0e0e",
            border: "1px solid #222",
          }}
        >
          {loading && <div style={{ padding: 12 }}>Loading symbols…</div>}
          {error && <div style={{ padding: 12, color: "#f88" }}>{error}</div>}
          {!loading && !error && pageSlice.length === 0 && (
            <div style={{ padding: 12, opacity: 0.8 }}>No symbols for this quote</div>
          )}

          {pageSlice.map((r) => (
            <button
              key={r.symbol}
              onClick={() => {
                onSelect(r.symbol); // Notify parent
                onClose();
              }}
              style={{
                width: "100%",
                textAlign: "left",
                background: "transparent",
                color: "#eee",
                padding: "10px 14px",
                borderBottom: "1px solid #1d1d1d",
                cursor: "pointer",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "#1a1a1a";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
              }}
            >
              <div style={{ fontWeight: 600 }}>
                {r.base}/{r.quote}
              </div>
              <div style={{ fontSize: 12, opacity: 0.6 }}>{r.symbol}</div>
            </button>
          ))}
        </div>

        <div style={{ display: "flex", gap: 8, justifyContent: "space-between", marginTop: 10 }}>
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
            style={{ 
              background: page <= 1 ? "#333" : "#222", 
              color: page <= 1 ? "#666" : "#eee", 
              borderRadius: 8, 
              padding: "6px 10px",
              cursor: page <= 1 ? "not-allowed" : "pointer"
            }}
          >
            ◀ Prev
          </button>
          <div style={{ opacity: 0.8, display: "flex", alignItems: "center" }}>
            Page {page}/{totalPages} • {filtered.length} pairs
          </div>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            style={{ 
              background: page >= totalPages ? "#333" : "#222", 
              color: page >= totalPages ? "#666" : "#eee", 
              borderRadius: 8, 
              padding: "6px 10px",
              cursor: page >= totalPages ? "not-allowed" : "pointer"
            }}
          >
            Next ▶
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}