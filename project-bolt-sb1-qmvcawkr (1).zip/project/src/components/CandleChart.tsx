import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  createChart, IChartApi, UTCTimestamp, CandlestickSeriesPartialOptions,
} from "lightweight-charts";
import { sma, ema, rsi } from "@/utils/indicators";
import { getKlines } from "../utils/binanceApi";

type TF = "15m"|"1h"|"4h"|"1d";

function toCandle(k: any[]) {
  return {
    time: (k[0]/1000) as UTCTimestamp,
    open: +k[1], high: +k[2], low: +k[3], close: +k[4], volume: +k[5],
  };
}

export default function CandleChart({
  symbol = "BTCUSDT", interval = "4h" as TF,
}: { symbol?: string; interval?: TF }) {
  const [sym, setSym] = useState(symbol);
  const [tf, setTf] = useState<TF>(interval);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const mainRef = useRef<HTMLDivElement>(null);
  const rsiRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const rsiChartRef = useRef<IChartApi | null>(null);

  // indicators toggles
  const [showSMA20, setSMA20] = useState(true);
  const [showSMA50, setSMA50] = useState(true);
  const [showEMA200, setEMA200] = useState(true);

  // listen to external “refresh-chart”
  useEffect(() => {
    const h = (e: any) => {
      if (e?.detail?.symbol) {
        setSym(e.detail.symbol);
        if (e.detail.tf) setTf(e.detail.tf);
      }
    };
    window.addEventListener("refresh-chart", h as any);
    return () => window.removeEventListener("refresh-chart", h as any);
  }, []);

  // build charts once
  useEffect(() => {
    if (!mainRef.current || chartRef.current) return;

    const chart = createChart(mainRef.current, {
      autoSize: true,
      layout: {
        textColor: "#d1d5db",      // हल्का grey
        background: { color: "#0f1115" }, // dark bg
      },
      grid: {
        vertLines: { color: "#1e293b", style: 1 },
        horzLines: { color: "#1e293b", style: 1 },
      },
      crosshair: {
        mode: 1, // magnet crosshair
        vertLine: {
          width: 1,
          color: "#4ade80", // हल्का green
          style: 1,
          labelBackgroundColor: "#0f172a",
        },
        horzLine: {
          width: 1,
          color: "#4ade80",
          style: 1,
          labelBackgroundColor: "#0f172a",
        },
      },
      rightPriceScale: {
        borderColor: "#1e293b",
        scaleMargins: { top: 0.1, bottom: 0.25 }, // नीचे RSI space
      },
      timeScale: {
        borderColor: "#1e293b",
        timeVisible: true,
        secondsVisible: false,
        fixLeftEdge: true,
        fixRightEdge: false,
        lockVisibleTimeRangeOnResize: true,
        rightOffset: 6,
        barSpacing: 8, // smooth zoom spacing
      },
      kineticScroll: { mouse: true, touch: true },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true },
      handleScale: { axisDoubleClickReset: true, mouseWheel: true, pinch: true, axisPressedMouseMove: true },
    });
    chartRef.current = chart;

    const rsiChart = createChart(rsiRef.current!, {
      autoSize: true,
      height: 120,
      layout: {
        textColor: "#d1d5db",
        background: { color: "#0b0e13" },
      },
      grid: {
        vertLines: { color: "#1e293b", style: 1 },
        horzLines: { color: "#1e293b", style: 1 },
      },
      crosshair: {
        mode: 1,
        vertLine: {
          width: 1,
          color: "#4ade80",
          style: 1,
          labelBackgroundColor: "#0f172a",
        },
        horzLine: {
          width: 1,
          color: "#4ade80",
          style: 1,
          labelBackgroundColor: "#0f172a",
        },
      },
      rightPriceScale: { borderColor: "#1e293b" },
      timeScale: {
        borderColor: "#1e293b",
        timeVisible: true,
        secondsVisible: false,
        fixLeftEdge: true,
        fixRightEdge: false,
        lockVisibleTimeRangeOnResize: true,
        rightOffset: 6,
        barSpacing: 8,
      },
      kineticScroll: { mouse: true, touch: true },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true },
      handleScale: { axisDoubleClickReset: true, mouseWheel: true, pinch: true, axisPressedMouseMove: true },
    });
    rsiChartRef.current = rsiChart;

    const resize = () => {
      chart.applyOptions({ width: mainRef.current!.clientWidth });
      rsiChart.applyOptions({ width: rsiRef.current!.clientWidth });
    };
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);

  // load & draw
  useEffect(() => {
    (async () => {
      if (!chartRef.current) return;
      setLoading(true); setErr(null);

      try {
        const raw = await getKlines(sym, tf, 200);
        const candles = raw.map(toCandle);
        drawAll(candles);
      } catch (e: any) {
        setErr(e?.message || "Failed");
      } finally {
        setLoading(false);
      }
    })();
  }, [sym, tf, showSMA20, showSMA50, showEMA200]);

  const title = useMemo(() => `${sym.replace("USDT","/USDT")} • ${tf.toUpperCase()}`, [sym, tf]);

  function drawAll(candles: ReturnType<typeof toCandle>[]) {
    const chart = chartRef.current!;
    chart.remove(); // fully recreate to clear old series quickly
    const newChart = createChart(mainRef.current!, {
      autoSize: true,
      layout: {
        textColor: "#d1d5db",
        background: { color: "#0f1115" },
      },
      grid: {
        vertLines: { color: "#1e293b", style: 1 },
        horzLines: { color: "#1e293b", style: 1 },
      },
      crosshair: {
        mode: 1,
        vertLine: {
          width: 1,
          color: "#4ade80",
          style: 1,
          labelBackgroundColor: "#0f172a",
        },
        horzLine: {
          width: 1,
          color: "#4ade80",
          style: 1,
          labelBackgroundColor: "#0f172a",
        },
      },
      rightPriceScale: {
        borderColor: "#1e293b",
        scaleMargins: { top: 0.1, bottom: 0.25 },
      },
      timeScale: {
        borderColor: "#1e293b",
        timeVisible: true,
        secondsVisible: false,
        fixLeftEdge: true,
        fixRightEdge: false,
        lockVisibleTimeRangeOnResize: true,
        rightOffset: 6,
        barSpacing: 8,
      },
      kineticScroll: { mouse: true, touch: true },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true },
      handleScale: { axisDoubleClickReset: true, mouseWheel: true, pinch: true, axisPressedMouseMove: true },
    });
    chartRef.current = newChart;

    const candleSeries = newChart.addCandlestickSeries({
      wickUpColor: "#16c784",
      wickDownColor: "#ea3943",
      upColor: "#16c784",
      downColor: "#ea3943",
      borderVisible: false,
    } as CandlestickSeriesPartialOptions);

    candleSeries.setData(candles);

    // Volume
    const volumeSeries = newChart.addHistogramSeries({
      priceScaleId: "",
      color: "#60a5fa",
      scaleMargins: { top: 0.8, bottom: 0 },
    });
    
    const volumeData = candles.map(c => ({ 
      time: c.time, 
      value: c.volume,
      color: c.close >= c.open ? "#16c784" : "#ea3943"
    }));
    volumeSeries.setData(volumeData);

    // overlays
    const closes = candles.map(c => c.close);
    const times = candles.map(c => c.time);

    if (showSMA20) {
      const l = newChart.addLineSeries({ color: "#fbbf24", lineWidth: 2 });
      const v = sma(closes, 20);
      const smaData = times.map((t,i) => ({ 
        time: t, 
        value: isFinite(v[i]) && !isNaN(v[i]) ? v[i] : null 
      })).filter(item => item.value !== null);
      l.setData(smaData);
    }
    if (showSMA50) {
      const l = newChart.addLineSeries({ color: "#22d3ee", lineWidth: 2 });
      const v = sma(closes, 50);
      const smaData = times.map((t,i) => ({ 
        time: t, 
        value: isFinite(v[i]) && !isNaN(v[i]) ? v[i] : null 
      })).filter(item => item.value !== null);
      l.setData(smaData);
    }
    if (showEMA200) {
      const l = newChart.addLineSeries({ color: "#a78bfa", lineWidth: 2 });
      const v = ema(closes, 200);
      const emaData = times.map((t,i) => ({ 
        time: t, 
        value: isFinite(v[i]) && !isNaN(v[i]) ? v[i] : null 
      })).filter(item => item.value !== null);
      l.setData(emaData);
    }

    // ---- RSI bottom panel ----
    const rsiChart = rsiChartRef.current!;
    rsiChart.remove();
    const newRSI = createChart(rsiRef.current!, {
      autoSize: true,
      height: 120,
      layout: {
        textColor: "#d1d5db",
        background: { color: "#0b0e13" },
      },
      grid: {
        vertLines: { color: "#1e293b", style: 1 },
        horzLines: { color: "#1e293b", style: 1 },
      },
      crosshair: {
        mode: 1,
        vertLine: {
          width: 1,
          color: "#4ade80",
          style: 1,
          labelBackgroundColor: "#0f172a",
        },
        horzLine: {
          width: 1,
          color: "#4ade80",
          style: 1,
          labelBackgroundColor: "#0f172a",
        },
      },
      rightPriceScale: { borderColor: "#1e293b" },
      timeScale: {
        borderColor: "#1e293b",
        timeVisible: true,
        secondsVisible: false,
        fixLeftEdge: true,
        fixRightEdge: false,
        lockVisibleTimeRangeOnResize: true,
        rightOffset: 6,
        barSpacing: 8,
      },
      kineticScroll: { mouse: true, touch: true },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true },
      handleScale: { axisDoubleClickReset: true, mouseWheel: true, pinch: true, axisPressedMouseMove: true },
    });
    rsiChartRef.current = newRSI;

    const rsiLine = newRSI.addLineSeries({ lineWidth: 2 });
    const rvals = rsi(closes, 14);
    const rsiData = times.map((t,i) => ({ 
      time: t, 
      value: isFinite(rvals[i]) && !isNaN(rvals[i]) ? rvals[i] : null 
    })).filter(item => item.value !== null);
    rsiLine.setData(rsiData);

    // 30/70 levels
    const lvl = (v:number)=> newRSI.createPriceLine({ price: v, color: "#374151", lineWidth: 1, lineStyle: 2, axisLabelVisible: true });
    lvl(30); lvl(70);

    // sync scroll/zoom
    const ts1 = newChart.timeScale(), ts2 = newRSI.timeScale();
    ts1.subscribeVisibleLogicalRangeChange(() => {
      const r = ts1.getVisibleLogicalRange();
      if (r) ts2.setVisibleLogicalRange(r);
    });
    ts2.subscribeVisibleLogicalRangeChange(() => {
      const r = ts2.getVisibleLogicalRange();
      if (r) ts1.setVisibleLogicalRange(r);
    });
  }

  return (
    <div className="rounded-2xl overflow-hidden border border-[#1b2430]">
      {/* Header: name + timeframe + toggles */}
      <div className="flex flex-wrap items-center gap-2 px-3 py-2 bg-[#0b0e13] border-b border-[#1b2430]">
        <div className="font-semibold text-white mr-2 text-lg">{sym.replace("USDT","/USDT")}</div>
        <div className="flex items-center gap-1">
          {(["15m","1h","4h","1d"] as TF[]).map(t=>(
            <button key={t} onClick={()=>setTf(t)}
              className="px-2 py-1 rounded text-sm"
              style={{background: tf===t? "#0b5fff":"#1d2632", color:"#fff"}}>{t}</button>
          ))}
        </div>
        <div className="ml-auto flex items-center gap-3 text-xs text-slate-300">
          <label className="flex items-center gap-1 cursor-pointer"><input type="checkbox" checked={showSMA20} onChange={e=>setSMA20(e.target.checked)}/>SMA-20</label>
          <label className="flex items-center gap-1 cursor-pointer"><input type="checkbox" checked={showSMA50} onChange={e=>setSMA50(e.target.checked)}/>SMA-50</label>
          <label className="flex items-center gap-1 cursor-pointer"><input type="checkbox" checked={showEMA200} onChange={e=>setEMA200(e.target.checked)}/>EMA-200</label>
        </div>
      </div>

      <div ref={mainRef} style={{height: 420, width: "100%"}} />
      <div ref={rsiRef} style={{height: 140, width: "100%"}} />

      {loading && <div className="p-3 text-sm text-slate-300">Loading {title}…</div>}
      {err && <div className="p-3 text-sm text-red-400">Chart error: {err}</div>}
    </div>
  );
}
