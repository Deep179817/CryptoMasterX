import React, { useState } from "react";
import StaticCoinsPopover from "./staticCoinsPopover";
import AllCoinsDrawer from "./AllCoinsDrawer";

export default function MarketsSection({
  onPickSymbol,
}: {
  onPickSymbol: (s: string) => void;
}) {
  const [staticOpen, setStaticOpen] = useState(false);
  const [allCoinsOpen, setAllCoinsOpen] = useState(false);

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
          📈 Markets
        </h3>
        <div className="flex gap-2">
          <button
            onClick={() => setStaticOpen(true)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors duration-200"
          >
            Top Coins
          </button>
          <button
            onClick={() => setAllCoinsOpen(true)}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors duration-200"
          >
            All Coins
          </button>
        </div>
      </div>

      <div className="text-sm text-gray-600">
        Select a cryptocurrency to view its chart and generate trading analysis
      </div>

      <StaticCoinsPopover
        open={staticOpen}
        onClose={() => setStaticOpen(false)}
        onPick={(sym) => onPickSymbol(sym)}
      />

      <AllCoinsDrawer
        open={allCoinsOpen}
        onClose={() => setAllCoinsOpen(false)}
        onSelect={(sym) => onPickSymbol(sym)}
      />
    </div>
  );
}