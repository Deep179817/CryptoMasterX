import React, { useState, useEffect } from 'react';
import { RefreshCw, Copy, Share, TrendingUp, TrendingDown } from 'lucide-react';
import { get24hTicker } from '../utils/binanceApi';
import { getKlines } from '../utils/binanceApi';

interface CoinData {
  symbol: string;
  price: string;
  change24h: string;
  high24h: string;
  low24h: string;
}

interface PostSettings {
  language: 'english' | 'hindi';
  bias: 'bullish' | 'bearish' | 'auto';
}

interface AnalysisData {
  currentPrice: number;
  changePct: number;
  high24: number;
  low24: number;
  lastClose: number;
  atr: number;
  direction: 'bullish' | 'bearish';
  entry: number;
  stopLoss: number;
  target1: number;
  target2: number;
  target3: number;
  rrr: number;
  duration: string;
}

const POPULAR_COINS = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT'];

interface SocialAutoPostProps {
  symbol?: string;
}

const SocialAutoPost: React.FC<SocialAutoPostProps> = ({ symbol = 'BTCUSDT' }) => {
  const [selectedCoin, setSelectedCoin] = useState(symbol);
  const [coinDataList, setCoinDataList] = useState<CoinData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [generatedPost, setGeneratedPost] = useState('');
  const [settings, setSettings] = useState<PostSettings>({
    language: 'english',
    bias: 'auto'
  });
  const [analysisData, setAnalysisData] = useState<AnalysisData | null>(null);

  // Retry fetch helper function
  const fetchWithRetry = async <T,>(fetchFn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> => {
    for (let i = 0; i < retries; i++) {
      try {
        return await fetchFn();
      } catch (error) {
        if (i === retries - 1) {
          throw error;
        }
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, delay * (i + 1)));
      }
    }
    throw new Error('Max retries exceeded');
  };

  // Calculate ATR(14) from klines data
  const calculateATR = (klines: any[]): number => {
    if (klines.length < 15) return 0;
    
    const trValues: number[] = [];
    
    for (let i = 1; i < Math.min(klines.length, 150); i++) {
      const current = klines[i];
      const previous = klines[i - 1];
      
      const high = Number(current[2]);
      const low = Number(current[3]);
      const prevClose = Number(previous[4]);
      
      const tr = Math.max(
        high - low,
        Math.abs(high - prevClose),
        Math.abs(low - prevClose)
      );
      
      trValues.push(tr);
    }
    
    // Calculate ATR(14) - Simple Moving Average of last 14 TR values
    if (trValues.length < 14) return 0;
    
    const last14TR = trValues.slice(-14);
    const atr = last14TR.reduce((sum, tr) => sum + tr, 0) / 14;
    
    return atr;
  };

  // Calculate SMA(50) for trend determination
  const calculateSMA50 = (klines: any[]): number => {
    if (klines.length < 50) return 0;
    
    const last50Closes = klines.slice(-50).map((k: any) => Number(k[4]));
    return last50Closes.reduce((sum, close) => sum + close, 0) / 50;
  };

  // Format price based on value
  const formatPrice = (price: number): string => {
    if (price >= 1) {
      return price.toFixed(2);
    } else if (price >= 0.01) {
      return price.toFixed(4);
    } else {
      return price.toFixed(6);
    }
  };

  // Get duration hint based on ATR/Price ratio
  const getDurationHint = (atr: number, price: number): string => {
    const ratio = atr / price;
    if (ratio < 0.01) return '1–2 days';
    if (ratio <= 0.02) return '6–12 hours';
    return '2–4 hours';
  };

  // Fetch 24h ticker data for all coins
  const fetch24hData = async (): Promise<void> => {
    try {
      const promises = POPULAR_COINS.map(async (symbol) => {
        const data = await fetchWithRetry(() => get24hTicker(symbol));
        
        return {
          symbol,
          price: data.lastPrice,
          change24h: data.priceChangePercent,
          high24h: data.highPrice,
          low24h: data.lowPrice
        };
      });
      
      const results = await Promise.all(promises);
      setCoinDataList(results);
    } catch (err) {
      console.error('Error fetching 24h data:', err);
      setError('Failed to fetch market data');
    }
  };

  // Fetch analysis data for selected coin
  const fetchAnalysisData = async (symbol: string): Promise<void> => {
    try {
      setLoading(true);
      setError('');
      
      // Fetch 24h stats and klines concurrently
      const [stats, klines] = await Promise.all([
        fetchWithRetry(() => get24hTicker(symbol)),
        fetchWithRetry(() => getKlines(symbol, '1h', 100))
      ]);
      
      // Calculate metrics
      const currentPrice = Number(stats.lastPrice);
      const changePct = Number(stats.priceChangePercent);
      const high24 = Number(stats.highPrice);
      const low24 = Number(stats.lowPrice);
      const lastClose = Number(klines[klines.length - 1][4]);
      const atr = calculateATR(klines);
      const sma50 = calculateSMA50(klines);
      
      // Determine direction
      let direction: 'bullish' | 'bearish';
      if (settings.bias === 'auto') {
        direction = (changePct >= 0 && lastClose > sma50) ? 'bullish' : 'bearish';
      } else {
        direction = settings.bias as 'bullish' | 'bearish';
      }
      
      // Calculate levels
      const entry = lastClose;
      let stopLoss: number, target1: number, target2: number, target3: number;
      
      if (direction === 'bullish') {
        stopLoss = entry - atr;
        target1 = entry + atr;
        target2 = entry + (2 * atr);
        target3 = entry + (3 * atr);
      } else {
        stopLoss = entry + atr;
        target1 = entry - atr;
        target2 = entry - (2 * atr);
        target3 = entry - (3 * atr);
      }
      
      const rrr = Math.abs((target1 - entry) / (entry - stopLoss));
      const duration = getDurationHint(atr, entry);
      
      const analysis: AnalysisData = {
        currentPrice,
        changePct,
        high24,
        low24,
        lastClose,
        atr,
        direction,
        entry,
        stopLoss,
        target1,
        target2,
        target3,
        rrr,
        duration
      };
      
      setAnalysisData(analysis);
      
    } catch (err) {
      console.error('Error fetching analysis data:', err);
      setError('Failed to fetch analysis data');
    } finally {
      setLoading(false);
    }
  };

  // Generate social media post
  const generatePost = async (): Promise<void> => {
    if (!analysisData) return;
    
    try {
      setLoading(true);
      
      const { direction, entry, stopLoss, target1, target2, target3, rrr, duration, changePct } = analysisData;
      
      let post = '';
      
      if (settings.language === 'english') {
        const trendIcon = direction === 'bullish' ? '🚀' : '📉';
        const biasText = direction === 'bullish' ? 'BULLISH' : 'BEARISH';
        
        post = `🔥 ${selectedCoin.replace('USDT', '/USDT')} ${biasText} SETUP ${trendIcon}

📊 Current Price: $${formatPrice(entry)}
📈 24h Change: ${changePct >= 0 ? '+' : ''}${changePct.toFixed(2)}%
⏰ Duration: ${duration}

🎯 TRADING LEVELS:
• Entry: $${formatPrice(entry)}
• Stop Loss: $${formatPrice(stopLoss)}
• Target 1: $${formatPrice(target1)}
• Target 2: $${formatPrice(target2)}
• Target 3: $${formatPrice(target3)}
• Risk/Reward: 1:${rrr.toFixed(1)}

📋 ANALYSIS:
${direction === 'bullish' ? 
  '• Price showing bullish momentum\n• Breaking above key resistance\n• Volume supporting the move' :
  '• Price showing bearish pressure\n• Breaking below key support\n• Selling volume increasing'
}

⚠️ Risk Management:
• Never risk more than 2% of your portfolio
• Always use stop losses
• Take profits at targets

#Crypto #Trading #${selectedCoin.replace('USDT', '')} #TechnicalAnalysis`;
      } else {
        // Hindi (Roman) version
        const trendIcon = direction === 'bullish' ? '🚀' : '📉';
        const biasText = direction === 'bullish' ? 'BULLISH' : 'BEARISH';
        
        post = `🔥 ${selectedCoin.replace('USDT', '/USDT')} ${biasText} SETUP ${trendIcon}

📊 Current Price: $${formatPrice(entry)}
📈 24h Change: ${changePct >= 0 ? '+' : ''}${changePct.toFixed(2)}%
⏰ Duration: ${duration}

🎯 TRADING LEVELS:
• Entry: $${formatPrice(entry)}
• Stop Loss: $${formatPrice(stopLoss)}
• Target 1: $${formatPrice(target1)}
• Target 2: $${formatPrice(target2)}
• Target 3: $${formatPrice(target3)}
• Risk/Reward: 1:${rrr.toFixed(1)}

📋 ANALYSIS:
${direction === 'bullish' ? 
  '• Price mein bullish momentum dikh raha hai\n• Key resistance ko break kar raha hai\n• Volume support kar raha hai move ko' :
  '• Price mein bearish pressure hai\n• Key support ko break kar raha hai\n• Selling volume badh raha hai'
}

⚠️ Risk Management:
• Kabhi bhi 2% se zyada risk mat lo
• Hamesha stop loss use karo
• Targets par profit book karo

#Crypto #Trading #${selectedCoin.replace('USDT', '')} #TechnicalAnalysis`;
      }
      
      setGeneratedPost(post);
    } catch (err) {
      console.error('Error generating post:', err);
      setError('Failed to generate post');
    } finally {
      setLoading(false);
    }
  };

  // Copy to clipboard
  const copyToClipboard = async (): Promise<void> => {
    try {
      await navigator.clipboard.writeText(generatedPost);
      // Could add a toast notification here
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  // Share functions
  const shareToTwitter = (): void => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(generatedPost)}`;
    window.open(url, '_blank');
  };

  const shareToFacebook = (): void => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent('')}&quote=${encodeURIComponent(generatedPost)}`;
    window.open(url, '_blank');
  };

  const nativeShare = async (): Promise<void> => {
    if (navigator.share) {
      try {
        await navigator.share({ text: generatedPost });
      } catch (err) {
        console.error('Share failed:', err);
      }
    }
  };

  // Handle coin selection
  const handleCoinSelect = (symbol: string): void => {
    setSelectedCoin(symbol);
    fetchAnalysisData(symbol);
  };

  // Handle refresh data
  const handleRefreshData = (): void => {
    fetch24hData();
    fetchAnalysisData(selectedCoin);
  };

  // Initialize data
  useEffect(() => {
    fetch24hData();
    fetchAnalysisData(selectedCoin);
  }, []);

  // Update selected coin when currentSymbol prop changes
  useEffect(() => {
    if (symbol && symbol !== selectedCoin) {
      setSelectedCoin(symbol);
      fetchAnalysisData(symbol);
    }
  }, [symbol]);

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100">
      <div className="p-4 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
          📈 Crypto Social Auto-Post
        </h3>
        <p className="text-sm text-gray-600 mt-1">
          Generate professional crypto trading analysis and share on social media
        </p>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Coin Selector */}
          <div>
            <h4 className="text-sm font-semibold text-gray-700 mb-3">Popular Coins</h4>
            <div className="space-y-2">
              {POPULAR_COINS.map((symbol) => {
                const coinData = coinDataList.find(c => c.symbol === symbol);
                const isSelected = selectedCoin === symbol;
                const changePct = coinData ? Number(coinData.change24h) : 0;
                
                return (
                  <button
                    key={symbol}
                    onClick={() => handleCoinSelect(symbol)}
                    className={`w-full p-3 rounded-lg border text-left transition-colors duration-200 ${
                      isSelected
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-gray-900">
                          {symbol.replace('USDT', '')}/USDT
                        </div>
                        {coinData && (
                          <div className="text-sm text-gray-600">
                            ${formatPrice(Number(coinData.price))}
                          </div>
                        )}
                      </div>
                      {coinData && (
                        <div className={`text-sm font-medium px-2 py-1 rounded ${
                          changePct >= 0
                            ? 'text-green-700 bg-green-100'
                            : 'text-red-700 bg-red-100'
                        }`}>
                          {changePct >= 0 ? '+' : ''}{changePct.toFixed(2)}%
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
          
          {/* Right Column - Generated Post */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-semibold text-gray-700">Generated Post</h4>
              <div className="flex gap-2">
                <button
                  onClick={handleRefreshData}
                  disabled={loading}
                  className="flex items-center gap-1 px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200 disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                  Refresh Data
                </button>
                <button
                  onClick={generatePost}
                  disabled={!analysisData || loading}
                  className="px-3 py-1 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors duration-200 disabled:opacity-50"
                >
                  Generate Post
                </button>
              </div>
            </div>
            
            {error && (
              <div className="mb-3 p-2 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
                {error}
              </div>
            )}
            
            <textarea
              value={generatedPost}
              readOnly
              placeholder="Click 'Generate Post' to create analysis..."
              className="w-full h-64 p-3 border border-gray-200 rounded-lg resize-none font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            
            {/* Settings Row */}
            <div className="flex items-center justify-between mt-3 mb-3">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Language:</span>
                  <select
                    value={settings.language}
                    onChange={(e) => setSettings(prev => ({ ...prev, language: e.target.value as 'english' | 'hindi' }))}
                    className="text-sm border border-gray-200 rounded px-2 py-1"
                  >
                    <option value="english">English</option>
                    <option value="hindi">Roman Hindi</option>
                  </select>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Bias:</span>
                  <select
                    value={settings.bias}
                    onChange={(e) => setSettings(prev => ({ ...prev, bias: e.target.value as 'bullish' | 'bearish' | 'auto' }))}
                    className="text-sm border border-gray-200 rounded px-2 py-1"
                  >
                    <option value="auto">Auto</option>
                    <option value="bullish">Bullish</option>
                    <option value="bearish">Bearish</option>
                  </select>
                </div>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={copyToClipboard}
                disabled={!generatedPost}
                className="flex items-center gap-1 px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors duration-200 disabled:opacity-50"
              >
                <Copy className="w-4 h-4" />
                Copy Text
              </button>
              
              <button
                onClick={shareToTwitter}
                disabled={!generatedPost}
                className="px-3 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm transition-colors duration-200 disabled:opacity-50"
              >
                Post to X
              </button>
              
              <button
                onClick={shareToFacebook}
                disabled={!generatedPost}
                className="px-3 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-sm transition-colors duration-200 disabled:opacity-50"
              >
                Post to Facebook
              </button>
              
              {navigator.share && (
                <button
                  onClick={nativeShare}
                  disabled={!generatedPost}
                  className="flex items-center gap-1 px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg text-sm transition-colors duration-200 disabled:opacity-50"
                >
                  <Share className="w-4 h-4" />
                  Share
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SocialAutoPost;