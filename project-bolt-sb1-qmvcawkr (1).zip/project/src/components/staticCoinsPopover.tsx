import React from "react";
import { createPortal } from "react-dom";
import { topCoinsUSDT } from "@/data/topCoins";

export default function StaticCoinsPopover({
  open,
  onClose,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (symbol: string) => void;
}) {
  if (!open) return null;
  
  return createPortal(
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,.4)",
        zIndex: 1000,
        display: "flex",
        justifyContent: "flex-end",
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "min(520px,95vw)",
          height: "100%",
          background: "#111",
          color: "#eee",
          padding: 16,
          boxShadow: "0 0 24px rgba(0,0,0,.35)",
          overflow: "hidden",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", marginBottom: 12 }}>
          <h3 style={{ margin: 0 }}>Top Coins (Static • USDT)</h3>
          <button
            onClick={onClose}
            style={{ marginLeft: "auto", background: "#2a2a2a", color: "#fff", borderRadius: 8, padding: "6px 10px" }}
          >
            ✕
          </button>
        </div>

        <div style={{ height: "calc(100% - 60px)", overflow: "auto", border: "1px solid #222", borderRadius: 12 }}>
          {topCoinsUSDT.map((r) => (
            <button
              key={r.symbol}
              onClick={() => {
                onPick(r.symbol);   // chart + post ke liye parent ko notify
                onClose();
              }}
              style={{
                width: "100%",
                textAlign: "left",
                padding: "10px 12px",
                background: "transparent",
                color: "#eee",
                borderBottom: "1px solid #1d1d1d",
                cursor: "pointer",
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              <span style={{ fontWeight: 600 }}>
                {r.base}/{r.quote}
                <span style={{ opacity: 0.6, fontSize: 12, marginLeft: 8 }}>{r.symbol}</span>
              </span>
              <span style={{ opacity: 0.7 }}>Tap to load</span>
            </button>
          ))}
        </div>
      </div>
    </div>,
    document.body
  );
}
