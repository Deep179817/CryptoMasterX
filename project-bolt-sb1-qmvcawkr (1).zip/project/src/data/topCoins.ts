export const topCoinsUSDT = [
  "BTC","ETH","XRP","SOL","ADA","DOGE","BNB","TRX","LINK","SUI","LTC",
  "AVAX","UNI","PEPE","ARB","AAVE","HBAR","BCH","XLM","DOT","FIL","APT",
  "NEAR","TON","CRV","SHIB","ZEC","ETC","ONDO","TIA","ATOM","TAO","RAY",
  "LRC","TOWNS","INJ","PORTO","POL","SEI","OP","LDO","API3","WLD","BAT",
  "PENGU","ALPINE","WBTC","WIF","BONK","CTSI","SKL","GALA","LA","PROVE"
].map(base => ({ symbol: `${base}USDT`, base, quote: "USDT" }));