// Use public mirror (CORS open) for all environments
const BASE = "https://data-api.binance.vision/api/v3";

async function j<T = any>(url: string): Promise<T> {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

export const get24hStats = (s: string) => j(`${BASE}/ticker/24hr?symbol=${s}`);
export const getTickerPrice = (s: string) => j(`${BASE}/ticker/price?symbol=${s}`);
export const getKlines = (symbol: string, interval: string, limit: number) => 
  j(`${BASE}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);

export const getExchangeInfo = () => j(`${BASE}/exchangeInfo`);

export const topCoins = [
  { base: "BTC", quote: "USDT" },
  { base: "ETH", quote: "USDT" },
  { base: "XRP", quote: "USDT" },
  { base: "SOL", quote: "USDT" },
  { base: "ADA", quote: "USDT" },
  { base: "DOGE", quote: "USDT" },
  { base: "BNB", quote: "USDT" },
  { base: "TRX", quote: "USDT" },
  { base: "LINK", quote: "USDT" },
  { base: "SUI", quote: "USDT" },
  { base: "LTC", quote: "USDT" },
  { base: "AVAX", quote: "USDT" },
  { base: "UNI", quote: "USDT" },
  { base: "PEPE", quote: "USDT" },
  { base: "ARB", quote: "USDT" },
  { base: "AAVE", quote: "USDT" },
  { base: "HBAR", quote: "USDT" },
  { base: "BCH", quote: "USDT" },
  { base: "XLM", quote: "USDT" },
  { base: "DOT", quote: "USDT" },
  { base: "FIL", quote: "USDT" },
  { base: "APT", quote: "USDT" },
  { base: "NEAR", quote: "USDT" },
  { base: "TON", quote: "USDT" },
  { base: "CRV", quote: "USDT" },
  { base: "SHIB", quote: "USDT" },
  { base: "ZEC", quote: "USDT" },
  { base: "ETC", quote: "USDT" },
  { base: "ONDO", quote: "USDT" },
  { base: "TIA", quote: "USDT" },
  { base: "ATOM", quote: "USDT" },
  { base: "TAO", quote: "USDT" },
  { base: "RAY", quote: "USDT" },
  { base: "LRC", quote: "USDT" },
  { base: "TOWNS", quote: "USDT" },
  { base: "INJ", quote: "USDT" },
  { base: "PORTO", quote: "USDT" },
  { base: "POL", quote: "USDT" },
  { base: "SEI", quote: "USDT" },
  { base: "OP", quote: "USDT" },
  { base: "LDO", quote: "USDT" },
  { base: "API3", quote: "USDT" },
  { base: "WLD", quote: "USDT" },
  { base: "BAT", quote: "USDT" },
  { base: "PENGU", quote: "USDT" },
  { base: "ALPINE", quote: "USDT" },
  { base: "WBTC", quote: "USDT" },
  { base: "WIF", quote: "USDT" },
  { base: "BONK", quote: "USDT" },
  { base: "CTSI", quote: "USDT" },
  { base: "SKL", quote: "USDT" },
];

export const getAll24h = () => j<any[]>(`${BASE}/ticker/24hr`);
