// Binance API utilities with proper error handling and CORS support

const BASE_URL = 'https://data-api.binance.vision/api/v3';

interface KlineData {
  openTime: number;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
  closeTime: number;
  quoteAssetVolume: string;
  numberOfTrades: number;
  takerBuyBaseAssetVolume: string;
  takerBuyQuoteAssetVolume: string;
  ignore: string;
}

export const getKlines = async (
  symbol: string, 
  interval: string, 
  limit: number = 500
): Promise<any[]> => {
  const url = `${BASE_URL}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    if (!Array.isArray(data)) {
      throw new Error('Invalid klines data format');
    }
    
    return data;
  } catch (error) {
    console.error('Error fetching klines:', error);
    throw error;
  }
};

export const get24hTicker = async (symbol: string) => {
  const url = `${BASE_URL}/ticker/24hr?symbol=${symbol}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching 24h ticker:', error);
    throw error;
  }
};

export const getExchangeInfo = async () => {
  const url = `${BASE_URL}/exchangeInfo`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching exchange info:', error);
    throw error;
  }
};