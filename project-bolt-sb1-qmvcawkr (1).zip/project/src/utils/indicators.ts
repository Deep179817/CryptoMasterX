/**
 * Technical Indicators for Trading Charts
 */

/**
 * Simple Moving Average (SMA)
 * @param data Array of price values
 * @param period Number of periods for the average
 * @returns Array of SMA values
 */
export function sma(data: number[], period: number): number[] {
  const result: number[] = [];
  
  if (!data || data.length === 0 || period <= 0) {
    return [];
  }
  
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(0); // Use 0 instead of NaN for better filtering
    } else {
      const sum = data.slice(i - period + 1, i + 1).reduce((acc, val) => acc + val, 0);
      result.push(sum / period);
    }
  }
  
  return result;
}

/**
 * Exponential Moving Average (EMA)
 * @param data Array of price values
 * @param period Number of periods for the average
 * @returns Array of EMA values
 */
export function ema(data: number[], period: number): number[] {
  const result: number[] = [];
  const multiplier = 2 / (period + 1);
  
  if (!data || data.length === 0 || period <= 0) {
    return [];
  }
  
  for (let i = 0; i < data.length; i++) {
    if (i === 0) {
      result.push(data[i]);
    } else if (i < period - 1) {
      // Use SMA for the first few values
      const sum = data.slice(0, i + 1).reduce((acc, val) => acc + val, 0);
      result.push(sum / (i + 1));
    } else {
      const emaValue = (data[i] - result[i - 1]) * multiplier + result[i - 1];
      result.push(emaValue);
    }
  }
  
  return result;
}

/**
 * Relative Strength Index (RSI)
 * @param data Array of price values
 * @param period Number of periods for RSI calculation (typically 14)
 * @returns Array of RSI values (0-100)
 */
export function rsi(data: number[], period: number = 14): number[] {
  const result: number[] = [];
  const gains: number[] = [];
  const losses: number[] = [];
  
  if (!data || data.length === 0 || period <= 0) {
    return [];
  }
  
  // Calculate price changes
  for (let i = 1; i < data.length; i++) {
    const change = data[i] - data[i - 1];
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? Math.abs(change) : 0);
  }
  
  // Calculate RSI
  for (let i = 0; i < data.length; i++) {
    if (i === 0) {
      result.push(50); // Neutral RSI for first value
    } else if (i < period) {
      result.push(50); // Neutral RSI until we have enough data
    } else {
      const avgGain = gains.slice(i - period, i).reduce((acc, val) => acc + val, 0) / period;
      const avgLoss = losses.slice(i - period, i).reduce((acc, val) => acc + val, 0) / period;
      
      if (avgLoss === 0) {
        result.push(100);
      } else {
        const rs = avgGain / avgLoss;
        const rsiValue = 100 - (100 / (1 + rs));
        result.push(rsiValue);
      }
    }
  }
  
  return result;
}