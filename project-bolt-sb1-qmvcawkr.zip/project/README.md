# CryptoStarterX MVP

A professional cryptocurrency trading application built with React, TypeScript, and TradingView's Lightweight Charts.

## Features

- **Interactive Charts**: Real-time candlestick charts with technical indicators (SMA, EMA, RSI)
- **Market Data**: Live cryptocurrency prices from Binance API
- **Social Media Integration**: Auto-generate trading analysis posts for social platforms
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Professional UI**: Modern design with dark theme and smooth animations

## Technical Stack

- **Frontend**: React 18 + TypeScript
- **Charts**: TradingView Lightweight Charts
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Build Tool**: Vite
- **API**: Binance Public API

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

## Project Structure

```
src/
├── components/          # React components
│   ├── CandleChart.tsx     # Main trading chart
│   ├── SocialAutoPost.tsx  # Social media post generator
│   ├── MarketsSection.tsx  # Market selection interface
│   └── ...
├── utils/              # Utility functions
│   ├── binanceApi.ts      # API integration
│   ├── indicators.ts      # Technical indicators
│   └── ...
└── data/               # Static data
    └── topCoins.ts        # Popular cryptocurrency list
```

## Features Overview

### Trading Charts
- Real-time candlestick data
- Volume visualization
- Technical indicators (SMA-20, SMA-50, EMA-200, RSI)
- Interactive crosshair and zoom
- Multiple timeframes (15m, 1h, 4h, 1d)

### Market Data
- Live prices from Binance
- 24h price changes
- Support for 50+ popular cryptocurrencies
- Search functionality for all trading pairs

### Social Media Integration
- Auto-generate professional trading analysis
- Support for English and Hindi (Roman)
- Bullish/Bearish bias options
- One-click sharing to Twitter, Facebook
- Copy-to-clipboard functionality

## API Usage

The application uses Binance's public API endpoints:
- Market data: `https://data-api.binance.vision/api/v3/`
- No API key required for public endpoints
- CORS-enabled for browser usage

## Deployment

The application is deployed on Bolt Hosting:
- Live URL: https://cryptoblasterx-tmj0.bolt.host
- Automatic builds from main branch
- CDN distribution for global performance

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Disclaimer

This application is for educational and informational purposes only. Always do your own research before making any trading decisions. Cryptocurrency trading involves significant risk.