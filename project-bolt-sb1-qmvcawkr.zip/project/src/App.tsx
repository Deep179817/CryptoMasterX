import React from 'react';
import ErrorBoundary from './components/ErrorBoundary';
import SafeApp from './components/SafeApp';

function App() {
  return (
    <ErrorBoundary>
      <SafeApp />
    </ErrorBoundary>
  );
}

export default App;