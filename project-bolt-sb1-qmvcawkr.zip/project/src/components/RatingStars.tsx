import React from "react";

type Props = {
  value: number;                // 0..5 (can be fractional when readonly)
  onChange?: (v: number) => void;
  size?: number;                // px
  readOnly?: boolean;
  className?: string;
  label?: string;
};

export default function RatingStars({
  value,
  onChange,
  size = 22,
  readOnly = false,
  className = "",
  label = "Rate accuracy",
}: Props) {
  const stars = [1, 2, 3, 4, 5];

  function handleKey(e: React.KeyboardEvent<HTMLDivElement>, i: number) {
    if (readOnly) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onChange?.(i);
    }
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {label && <span className="text-sm text-slate-300">{label}</span>}
      <div className="flex" role="radiogroup" aria-label={label}>
        {stars.map((i) => {
          const filled = value >= i - 0.001;
          return (
            <div
              key={i}
              role="radio"
              aria-checked={filled}
              tabIndex={readOnly ? -1 : 0}
              onKeyDown={(e) => handleKey(e, i)}
              onClick={() => !readOnly && onChange?.(i)}
              className="cursor-pointer outline-none focus:ring-2 focus:ring-emerald-400 rounded"
              title={`${i} star${i > 1 ? "s" : ""}`}
            >
              <svg
                width={size}
                height={size}
                viewBox="0 0 24 24"
                fill={filled ? "#fbbf24" : "none"}
                stroke={filled ? "#fbbf24" : "#64748b"}
                strokeWidth="2"
              >
                <path d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
              </svg>
            </div>
          );
        })}
      </div>
    </div>
  );
}
