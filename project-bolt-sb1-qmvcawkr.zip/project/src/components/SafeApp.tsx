import React, { useState } from "react";
import MarketsSection from "@/components/MarketsSection";
import CandleChart from "@/components/CandleChart";
import SocialAutoPost from "@/components/SocialAutoPost";

export default function SafeApp() {
  const [symbol, setSymbol] = useState("BTCUSDT");

  const pick = (s: string) => {
    const S = s.toUpperCase();
    setSymbol(S);
    window.dispatchEvent(new CustomEvent("refresh-chart", { detail: { symbol: S, tf: "4h" } }));
    window.dispatchEvent(new CustomEvent("refresh-social-post", { detail: { symbol: S } }));
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-3 py-4 grid gap-4">
      {/* 🔝 HealthCheck हटाकर Generate Post सबसे ऊपर */}
      <SocialAutoPost symbol={symbol} />

      <MarketsSection onPickSymbol={pick} />
      <CandleChart symbol={symbol} interval="4h" />
    </div>
  );
}

