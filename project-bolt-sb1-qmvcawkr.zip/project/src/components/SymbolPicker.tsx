import React, { useState, useEffect, useRef } from 'react';
import { Search, RefreshCw, ChevronDown } from 'lucide-react';
import { getExchangeInfo } from '../utils/binanceApi';

interface SymbolMeta {
  symbol: string;
  base: string;
  quote: string;
}

class SymbolRegistryClass {
  private cache: SymbolMeta[] = [];
  private lastUpdated: number = 0;
  private readonly CACHE_KEY = 'bn_symbols_v1';
  private readonly CACHE_DURATION = 6 * 60 * 60 * 1000; // 6 hours
  
  public readonly quotes = ['USDT', 'FDUSD', 'USDC', 'BUSD', 'TUSD'];

  async load(force = false): Promise<SymbolMeta[]> {
    const now = Date.now();
    
    if (!force && this.cache.length > 0 && (now - this.lastUpdated) < this.CACHE_DURATION) {
      return this.cache;
    }

    if (!force) {
      try {
        const cached = localStorage.getItem(this.CACHE_KEY);
        if (cached) {
          const data = JSON.parse(cached);
          if ((now - data.updatedAt) < this.CACHE_DURATION && data.list.length > 0) {
            this.cache = data.list;
            this.lastUpdated = data.updatedAt;
            return this.cache;
          }
        }
      } catch (e) {
        console.warn('Failed to load cached symbols:', e);
      }
    }

    try {
      const data = await getExchangeInfo();
      
      const symbols: SymbolMeta[] = data.symbols
        .filter((s: any) => 
          s.status === 'TRADING' && 
          s.isSpotTradingAllowed === true &&
          s.permissions?.includes('SPOT')
        )
        .map((s: any) => ({
          symbol: s.symbol,
          base: s.baseAsset,
          quote: s.quoteAsset
        }))
        .sort((a: SymbolMeta, b: SymbolMeta) => {
          if (a.quote === 'USDT' && b.quote !== 'USDT') return -1;
          if (a.quote !== 'USDT' && b.quote === 'USDT') return 1;
          return a.base.localeCompare(b.base);
        });

      this.cache = symbols;
      this.lastUpdated = now;

      try {
        const cacheData = {
          updatedAt: now,
          list: symbols
        };
        localStorage.setItem(this.CACHE_KEY, JSON.stringify(cacheData));
      } catch (e) {
        console.warn('Failed to cache symbols:', e);
      }

      return symbols;
    } catch (error) {
      console.error('Failed to fetch exchange info:', error);
      
      if (this.cache.length > 0) {
        return this.cache;
      }
      
      throw error;
    }
  }

  search(query: string, quoteFilter = 'USDT'): SymbolMeta[] {
    if (!query.trim()) return [];
    
    const normalizedQuery = query.toLowerCase().trim();
    let filtered = this.cache;

    if (quoteFilter !== 'ALL') {
      filtered = filtered.filter(s => s.quote === quoteFilter);
    }

    const matches = filtered
      .map(symbol => {
        const baseLower = symbol.base.toLowerCase();
        const symbolLower = symbol.symbol.toLowerCase();
        
        let score = 0;
        
        if (baseLower === normalizedQuery) {
          score = 1000;
        } else if (baseLower.startsWith(normalizedQuery)) {
          score = 900;
        } else if (baseLower.includes(normalizedQuery)) {
          score = 800;
        } else if (symbolLower.startsWith(normalizedQuery)) {
          score = 700;
        } else if (symbolLower.includes(normalizedQuery)) {
          score = 600;
        }
        
        if (symbol.quote === 'USDT') {
          score += 10;
        }
        
        return { symbol, score };
      })
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
      .map(item => item.symbol);

    return matches;
  }

  findSymbol(query: string): SymbolMeta | null {
    const normalized = query.toUpperCase().replace(/\s+/g, '');
    return this.cache.find(s => s.symbol === normalized) || null;
  }

  tryWithQuote(base: string, quote: string): SymbolMeta | null {
    const symbol = base.toUpperCase() + quote.toUpperCase();
    return this.findSymbol(symbol);
  }
}

const SymbolRegistry = new SymbolRegistryClass();
interface SymbolPickerProps {
  onSymbolSelect: (symbol: string) => void;
  currentSymbol: string;
}

const SymbolPicker: React.FC<SymbolPickerProps> = ({ onSymbolSelect, currentSymbol }) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [results, setResults] = useState<SymbolMeta[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [quoteFilter, setQuoteFilter] = useState('USDT');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [isInitialized, setIsInitialized] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<NodeJS.Timeout>();

  // Initialize symbol registry
  useEffect(() => {
    const initializeRegistry = async () => {
      try {
        setLoading(true);
        setError('');
        await SymbolRegistry.load();
        setIsInitialized(true);
      } catch (err) {
        setError('Failed to load symbols');
        console.error('Symbol registry initialization failed:', err);
      } finally {
        setLoading(false);
      }
    };

    initializeRegistry();
  }, []);

  // Debounced search
  useEffect(() => {
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    debounceRef.current = setTimeout(() => {
      if (query.trim() && isInitialized) {
        const searchResults = SymbolRegistry.search(query, quoteFilter);
        setResults(searchResults);
        setSelectedIndex(-1);
        setIsOpen(searchResults.length > 0);
      } else {
        setResults([]);
        setIsOpen(false);
      }
    }, 150);

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, [query, quoteFilter, isInitialized]);

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < results.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && results[selectedIndex]) {
          handleSymbolSelect(results[selectedIndex].symbol);
        } else {
          handleManualEntry();
        }
        break;
      case 'Escape':
        e.preventDefault();
        setIsOpen(false);
        setSelectedIndex(-1);
        inputRef.current?.blur();
        break;
    }
  };

  // Handle manual symbol entry
  const handleManualEntry = () => {
    const normalized = query.toUpperCase().replace(/\s+/g, '');
    
    // Try exact match first
    let symbol = SymbolRegistry.findSymbol(normalized);
    
    // Try with current quote filter
    if (!symbol && quoteFilter !== 'ALL') {
      symbol = SymbolRegistry.tryWithQuote(normalized, quoteFilter);
    }
    
    // Try with USDT if not already tried
    if (!symbol && quoteFilter !== 'USDT') {
      symbol = SymbolRegistry.tryWithQuote(normalized, 'USDT');
    }

    if (symbol) {
      handleSymbolSelect(symbol.symbol);
    } else {
      setError('Unknown symbol');
      setTimeout(() => setError(''), 3000);
    }
  };

  // Handle symbol selection
  const handleSymbolSelect = (symbol: string) => {
    onSymbolSelect(symbol);
    setQuery('');
    setIsOpen(false);
    setSelectedIndex(-1);
    setError('');
    inputRef.current?.blur();
  };

  // Handle refresh
  const handleRefresh = async () => {
    try {
      setLoading(true);
      setError('');
      await SymbolRegistry.load(true);
      setIsInitialized(true);
    } catch (err) {
      setError('Failed to refresh symbols');
      console.error('Symbol refresh failed:', err);
    } finally {
      setLoading(false);
    }
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setSelectedIndex(-1);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <div className="flex gap-2 mb-3">
        {/* Search Input */}
        <div className="flex-1 relative">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              onFocus={() => {
                if (results.length > 0) setIsOpen(true);
              }}
              placeholder="Search any Binance pair (e.g., BTC, DOGE, RUNE)..."
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-300"
              disabled={loading}
            />
          </div>
          
          {error && (
            <div className="absolute top-full left-0 right-0 mt-1 text-xs text-red-600 bg-red-50 px-2 py-1 rounded border border-red-200">
              {error}
            </div>
          )}
        </div>

        {/* Quote Filter */}
        <div className="relative">
          <select
            value={quoteFilter}
            onChange={(e) => setQuoteFilter(e.target.value)}
            className="appearance-none bg-white border border-gray-200 rounded-lg px-3 py-2 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-300"
            disabled={loading}
          >
            <option value="USDT">USDT</option>
            <option value="FDUSD">FDUSD</option>
            <option value="USDC">USDC</option>
            <option value="BUSD">BUSD</option>
            <option value="TUSD">TUSD</option>
            <option value="ALL">ALL</option>
          </select>
          <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
        </div>

        {/* Refresh Button */}
        <button
          onClick={handleRefresh}
          disabled={loading}
          className="flex items-center justify-center w-10 h-10 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200 disabled:opacity-50"
          title="Refresh symbols"
        >
          <RefreshCw className={`w-4 h-4 text-gray-600 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Dropdown Results */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50 max-h-80 overflow-y-auto">
          {results.length > 0 ? (
            results.map((symbol, index) => (
              <button
                key={symbol.symbol}
                onClick={() => handleSymbolSelect(symbol.symbol)}
                className={`w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors duration-150 border-b border-gray-100 last:border-b-0 ${
                  index === selectedIndex ? 'bg-blue-50' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-gray-900">
                      {symbol.base}/{symbol.quote}
                    </div>
                    <div className="text-sm text-gray-500">
                      {symbol.symbol}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      TRADING
                    </span>
                  </div>
                </div>
              </button>
            ))
          ) : (
            <div className="px-4 py-3 text-sm text-gray-500 text-center">
              No symbols found
            </div>
          )}
        </div>
      )}

      {/* Current Symbol Display */}
      {currentSymbol && !query && (
        <div className="text-xs text-gray-600 mt-1">
          Current: <span className="font-mono font-medium">{currentSymbol}</span>
        </div>
      )}
    </div>
  );
};

export default SymbolPicker;