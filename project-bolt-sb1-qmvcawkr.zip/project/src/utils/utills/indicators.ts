// src/utils/indicators.ts
export type Candle = { time:number; open:number; high:number; low:number; close:number; volume:number };

export function sma(values: number[], len: number): number[] {
  const out: number[] = new Array(values.length).fill(NaN);
  let sum = 0;
  for (let i=0;i<values.length;i++){
    sum += values[i];
    if (i>=len) sum -= values[i-len];
    if (i>=len-1) out[i] = sum/len;
  }
  return out;
}

export function ema(values: number[], len: number): number[] {
  const out: number[] = new Array(values.length).fill(NaN);
  const k = 2/(len+1);
  let prev = values[0];
  out[0] = prev;
  for (let i=1;i<values.length;i++){
    const v = values[i]*k + prev*(1-k);
    out[i] = v;
    prev = v;
  }
  return out;
}

export function rsi(values: number[], len=14): number[] {
  const out: number[] = new Array(values.length).fill(NaN);
  let gain = 0, loss = 0;
  for (let i=1;i<=len;i++){
    const ch = values[i]-values[i-1];
    if (ch>=0) gain+=ch; else loss-=ch;
  }
  let avgG = gain/len, avgL = loss/len;
  out[len] = 100 - 100/(1 + (avgG/(avgL||1e-9)));
  for (let i=len+1;i<values.length;i++){
    const ch = values[i]-values[i-1];
    const g = ch>0?ch:0, l = ch<0?-ch:0;
    avgG = (avgG*(len-1)+g)/len;
    avgL = (avgL*(len-1)+l)/len;
    const rs = avgL===0 ? 100 : avgG/avgL;
    out[i] = 100 - 100/(1+rs);
  }
  return out;
}
