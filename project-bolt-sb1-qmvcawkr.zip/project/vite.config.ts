import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath, URL } from "node:url";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  server: {
    proxy: {
      // (agar binance proxy use kar rahe ho)
      "/binance": {
        target: "https://api.binance.com",
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/binance/, ""),
      },
    },
  },
});
